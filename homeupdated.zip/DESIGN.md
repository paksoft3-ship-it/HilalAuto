---
name: Premium Automotive Acquisition
colors:
  surface: '#FAFAFA'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#5c4039'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#916f67'
  outline-variant: '#e6bdb4'
  surface-tint: '#b62500'
  primary: '#b22300'
  on-primary: '#ffffff'
  primary-container: '#dd3003'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4a3'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2e1'
  on-secondary-container: '#656464'
  tertiary: '#005ab3'
  on-tertiary: '#ffffff'
  tertiary-container: '#0073e0'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad2'
  primary-fixed-dim: '#ffb4a3'
  on-primary-fixed: '#3d0600'
  on-primary-fixed-variant: '#8b1a00'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#d6e3ff'
  tertiary-fixed-dim: '#aac7ff'
  on-tertiary-fixed: '#001b3e'
  on-tertiary-fixed-variant: '#00468d'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  muted-text: '#888888'
  soft-text: '#AAAAAA'
  border-default: '#EEEEEE'
  accent-light: '#FFF2EF'
  accent-border: '#FFCDC4'
  whatsapp-green: '#25D366'
typography:
  hero-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: -1.5px
  hero-md:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: -1.5px
  hero-sm:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: -1.5px
  section-title:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -1.5px
  section-title-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -1px
  card-title:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0px
  label-micro:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  '4': 4px
  '8': 8px
  '12': 12px
  '16': 16px
  '24': 24px
  '32': 32px
  '44': 44px
  '60': 60px
  max-content-width: 1180px
---

## Brand & Style

The design system is engineered for a high-end Turkish automotive service specializing in the acquisition of damaged and non-standard vehicles. The brand personality is professional, efficient, and exceptionally trustworthy, moving away from the "scrapyard" aesthetic toward a premium, service-oriented experience.

The visual style is **Minimalist / Apple-inspired**, characterized by:
- **Absolute Clarity:** Eliminating all visual noise, including shadows, gradients, and decorative patterns.
- **Precision:** Utilizing ultra-thin 0.5px borders to define structure without adding weight.
- **High-End Utility:** A "flat-plus" approach where depth is communicated through subtle surface tonal shifts (#FFFFFF to #FAFAFA) rather than traditional elevation.
- **Conversion-Centricity:** Using a single, high-energy accent color to guide the user toward lead-generation actions (Quote, WhatsApp, Call).

## Colors

The palette is rooted in a "Clean White" philosophy. **Primary Background** (#FFFFFF) is the foundation for the majority of the UI, while **Surface** (#FAFAFA) is used to differentiate card components and secondary sections.

- **Primary (Accent):** The red-orange hue (#E8380D) is reserved exclusively for high-priority CTA elements and important status indicators.
- **Secondary (Dark):** Solid black (#111111) provides high-contrast grounding for heavy CTA sections or footer areas.
- **Neutral Hierarchy:** Typography uses a three-tier grayscale (#111111 for headings, #888888 for body, #AAAAAA for micro-labels) to ensure a clear information hierarchy without overwhelming the user.
- **WhatsApp Green:** A single-purpose utility color used only for direct chat integrations.

## Typography

This design system uses **Inter** exclusively to maintain a systematic, modern aesthetic. 

**Core Rules:**
- **Weight Limitation:** Use only 400 (Regular) and 500 (Medium). Never use Bold or Heavy weights.
- **Tightened Headings:** All headings (H1-H3) must utilize a `-1.5px` letter-spacing to create a compact, premium editorial feel.
- **Hierarchy:** Contrast is created through scale and color (Primary Text vs. Muted Text) rather than weight.
- **Mobile Scaling:** Hero headlines should aggressively scale down on mobile to prevent awkward line breaks while maintaining their visual impact.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for desktop, centering a max-width content area of 1180px with generous external margins.

**Spacing Rhythm:**
- **Vertical Rhythm:** Sections are separated by large white spaces (60px Desktop / 44px Tablet / 32px Mobile) to maintain the premium feel.
- **Component Padding:** Internal card and button padding must strictly pull from the 4px-60px scale.
- **Mobile First:** Content should stack vertically on mobile with a focus on high-touch targets (minimum 44px height for all interactive elements).

## Elevation & Depth

This system intentionally avoids traditional depth cues like box-shadows or gradients. Depth is achieved via **Bold Borders** and **Tonal Layers**:

- **0.5px Precision:** All containers, inputs, and dividers use a consistent 0.5px border (#EEEEEE).
- **Surface Layering:** Placing #FFFFFF cards onto a #FAFAFA background provides subtle separation without the visual weight of shadows.
- **Focus States:** Depth is simulated during interaction by changing border color (e.g., to the Accent color) rather than increasing elevation.

## Shapes

The shape language is sophisticated and modern, using specific radii for different component tiers:
- **Buttons & Inputs:** 8px radius for a clean, professional tool-like appearance.
- **Content Cards:** 14px radius to provide a softer, more inviting container for information.
- **Badges & Pills:** 20px (full pill) radius to distinguish them as non-interactive or secondary metadata elements.

## Components

### Logo
- **Style:** Text-based, no icon.
- **Execution:** "Hazar" in #111111 (Weight 500) and "Al" in #E8380D (Weight 500).

### Buttons
- **Primary:** #E8380D background, white text, 8px radius. Medium weight.
- **Secondary:** White background, #111111 text, 0.5px #EEEEEE border, 8px radius.
- **WhatsApp:** #25D366 background, white text. Can be used as a fixed floating action button (FAB) in the bottom right.

### Inputs
- **Style:** 0.5px #EEEEEE border, 8px radius.
- **Interaction:** On focus, the border shifts to #E8380D. Use #AAAAAA for placeholders. Ensure fields are large and touch-friendly for mobile lead generation.

### Cards
- **Style:** Surface or White background, 0.5px #EEEEEE border, 14px radius. 
- **Interaction:** Hover states should only utilize a subtle border color shift or internal color change, never a shadow.

### Navigation
- **Style:** Sticky top positioning, white background, 0.5px bottom border (#EEEEEE). 
- **Layout:** Logo on the left, primary navigation links centered, and a prominent "Teklif Al" CTA button on the right.

### Pills/Badges
- **Style:** #FFF2EF background, #E8380D text, #FFCDC4 (0.5px) border. Used for "7/24 Destek" or "Hızlı Ödeme" labels.